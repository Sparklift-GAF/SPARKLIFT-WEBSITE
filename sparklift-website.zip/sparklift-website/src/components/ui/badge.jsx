import React from "react";

export function Badge({ className = "", variant = "secondary", ...props }) {
  const base = "inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium";
  const v =
    variant === "secondary"
      ? "border-slate-200 bg-slate-100 text-slate-800"
      : "border-slate-200 bg-white text-slate-800";
  return <span className={`${base} ${v} ${className}`} {...props} />;
}
