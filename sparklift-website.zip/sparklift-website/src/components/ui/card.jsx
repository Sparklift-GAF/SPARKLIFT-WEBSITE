import React from "react";

export function Card({ className = "", ...props }) {
  return <div className={`rounded-2xl border ${className}`} {...props} />;
}

export function CardHeader({ className = "", ...props }) {
  return <div className={`p-6 ${className}`} {...props} />;
}

export function CardTitle({ className = "", ...props }) {
  return <h3 className={`font-semibold tracking-tight ${className}`} {...props} />;
}

export function CardDescription({ className = "", ...props }) {
  return <p className={`text-slate-600 ${className}`} {...props} />;
}

export function CardContent({ className = "", ...props }) {
  return <div className={`px-6 pb-6 ${className}`} {...props} />;
}
