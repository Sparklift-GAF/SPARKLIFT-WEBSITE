import React from "react";

export function Textarea({ className = "", ...props }) {
  return (
    <textarea
      className={`min-h-[110px] w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none focus:ring-2 focus:ring-slate-200 ${className}`}
      {...props}
    />
  );
}
