import React from "react";

const styles = {
  base: "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-2xl text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-300 disabled:pointer-events-none disabled:opacity-50",
  primary: "bg-slate-900 text-white hover:bg-slate-800",
  secondary: "bg-slate-100 text-slate-900 hover:bg-slate-200 border border-slate-200",
};

export function Button({ className = "", variant = "primary", ...props }) {
  const v = variant === "secondary" ? styles.secondary : styles.primary;
  return <button className={`${styles.base} ${v} px-4 py-2 ${className}`} {...props} />;
}
